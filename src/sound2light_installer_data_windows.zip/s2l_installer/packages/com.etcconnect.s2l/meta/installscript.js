function Component() {
	// create a shortcut in the start menu:
	if (installer.value("os") === "win") {
		component.addOperation("CreateShortcut", "@TargetDir@/s2l.exe",
							   "@UserStartMenuProgramsPath@/@StartMenuDir@/Sound2Light.lnk",
							   "workingDirectory=@TargetDir@",
							   "iconPath=@TargetDir@/etcicon.ico");
	}
}
