function Component() {
	// create a shortcut on the desktop:
	if (installer.value("os") === "win") {
		component.addOperation("CreateShortcut", "@TargetDir@/s2l.exe",
							   "@DesktopDir@/Sound2Light.lnk",
							   "workingDirectory=@TargetDir@",
							   "iconPath=@TargetDir@/etcicon.ico");
	}
}
