function Controller()
{
	// do not show Start Menu Dir Selection
	// because it should always appear in the same start menu dir:
	installer.setDefaultPageVisible(QInstaller.StartMenuSelection, false);
	// Component Selection is visible because of the option to create a desktop shortcut
	installer.setDefaultPageVisible(QInstaller.ComponentSelection, true);
}

Controller.prototype.TargetDirectoryPageCallback = function()
{
	// check each time the target dir changes if there already is a previous installation:
	var widget = gui.currentPageWidget();
	widget.TargetDirectoryLineEdit.textChanged.connect(this, Controller.prototype.checkForPreviousVersion);
	Controller.prototype.checkForPreviousVersion(widget.TargetDirectoryLineEdit.text);
}

Controller.prototype.checkForPreviousVersion = function (text) {
	if (text !== "" && installer.fileExists(text + "/components.xml")) {
		if(QMessageBox.question("UninstallPreviousVersion", "Uninstall Previous Version",
								"Please uninstall the previous version first.", QMessageBox.Ok | QMessageBox.No) === QMessageBox.Ok) {
			// do not ask for overwrite if there are some files left after uninstallation:
			installer.setMessageBoxAutomaticAnswer("OverwriteTargetDirectory", QMessageBox.Yes);
			// start uninstallation wizard:
			installer.execute(text + "/maintenancetool.exe")
		}
	}
}
